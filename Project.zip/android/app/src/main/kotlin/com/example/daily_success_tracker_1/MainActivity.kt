package com.example.daily_success_tracker_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
