class DailyRecord {
  DateTime date;
  bool isSuccess;

  DailyRecord({
    required this.date,
    required this.isSuccess,
  });
}